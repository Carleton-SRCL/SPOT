# AIAA_GNC2020_D4PG
Open-sourced D4PG implementation of a spacecraft proximity operations and docking task, presented in Hovell, K., and Ulrich, S., “On Deep Reinforcement Learning for Spacecraft Robotics Guidance,” AIAA Guidance, Navigation, and Control Conference, Orlando, FL, 6-10 Jan, 2020.

To run, first modify settings in environment_envs1_2.py and settings.py. Then run python3 on the main.py to begin training.
